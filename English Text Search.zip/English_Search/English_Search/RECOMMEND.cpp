﻿// RECOMMEND.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "RECOMMEND.h"
#include "afxdialogex.h"


// RECOMMEND 对话框

IMPLEMENT_DYNAMIC(RECOMMEND, CDialogEx)

RECOMMEND::RECOMMEND(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_RECOMMEND, pParent)
{

}

RECOMMEND::~RECOMMEND()
{
}

void RECOMMEND::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO2, m_Choice1);
	DDX_Control(pDX, IDC_COMBO3, m_Choice2);
	DDX_Control(pDX, IDC_COMBO4, m_Choice3);
	m_Font.CreatePointFont(110, _T("幼圆"));
	m_Choice1.SetFont(&m_Font);
	m_Choice2.SetFont(&m_Font);
	m_Choice3.SetFont(&m_Font);

	//显示下拉框内容
	std::ifstream In; std::string temp; int NUM;
	In.open(".\\Data\\keyword.txt", std::ios::in);
	while (In.peek() != EOF) {
		In >> temp;
		In >> NUM;
		temp.clear();
		for (int i = 0; i < NUM; i++) {
			In >> temp;
			if (!HasIt(keyword, temp)) {
				m_Choice1.AddString(CA2T(temp.c_str()));
				m_Choice2.AddString(CA2T(temp.c_str()));
				m_Choice3.AddString(CA2T(temp.c_str()));
				keyword.push_back(temp);
			}
			temp.clear();
		}
	}
}


BEGIN_MESSAGE_MAP(RECOMMEND, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &RECOMMEND::OnBnClickedButton1)
	ON_BN_CLICKED(IDOK, &RECOMMEND::OnBnClickedOk)
END_MESSAGE_MAP()


// RECOMMEND 消息处理程序


BOOL RECOMMEND::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class
	   // TODO: Add your specialized code here and/or call the base class
	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_RETURN)
			return TRUE;//截获消息 
	}
	return CDialog::PreTranslateMessage(pMsg);
}


void RECOMMEND::OnBnClickedButton1()
{
	RECOUT* m_Recout = new RECOUT;
	// TODO: 在此添加控件通知处理程序代码
	CString A, B, C;
	m_Choice1.GetWindowTextW(A);
	m_Choice2.GetWindowTextW(B);
	m_Choice3.GetWindowTextW(C);
	if (m_Recout->GetChoice(A, B, C))
		m_Recout->DoModal();
	delete(m_Recout);
}

bool RECOMMEND::HasIt(const std::vector<std::string>& emptyword, const std::string& Word)
{
	int end = keyword.size();
	for (int i = 0; i < end; i++) {
		if (Word == keyword[i])
			return true;
		else continue;
	}
	return false;
}


void RECOMMEND::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	CDialogEx::OnCancel();
}
