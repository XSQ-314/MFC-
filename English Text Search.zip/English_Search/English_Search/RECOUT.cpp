﻿// RECOUT.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "RECOUT.h"
#include "afxdialogex.h"


// RECOUT 对话框

IMPLEMENT_DYNAMIC(RECOUT, CDialogEx)

RECOUT::RECOUT(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_RECOUT, pParent)
{

}

RECOUT::~RECOUT()
{
}

void RECOUT::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB1, m_Tab);

	//初始化窗口
	Search();//搜索文章
	CreatText();//创建对应的CString
	Initialize();//初始化界面
}


BEGIN_MESSAGE_MAP(RECOUT, CDialogEx)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, &RECOUT::OnTcnSelchangeTab1)
	ON_BN_CLICKED(IDOK, &RECOUT::OnBnClickedOk)
END_MESSAGE_MAP()


// RECOUT 消息处理程序


void RECOUT::Initialize()
{
	m_Tab.InsertItem(0, _T("第一篇"));
	m_Tab.InsertItem(1, _T("第二篇"));
	m_Tab.InsertItem(2, _T("第三篇"));
	m_Tab.InsertItem(3, _T("第四篇"));
	m_Tab.InsertItem(4, _T("第五篇"));
	CRect rc;
	m_Tab.GetClientRect(rc);
	rc.top += 20;
	rc.bottom -= 0;
	rc.left += -30;
	rc.right -= 0;
	for (int i = 0; i < 5; i++) {
		m_Dlg[i] = new OUTTEXT;
		m_Dlg[i]->Create(IDD_OUT, &m_Tab);
		m_Dlg[i]->MoveWindow(&rc);
		if (!i)
			m_Dlg[i]->ShowWindow(SW_SHOW);
		else
			m_Dlg[i]->ShowWindow(SW_HIDE);
		m_Dlg[i]->ShowText(m_Text[i]);
	}
}

void RECOUT::Search()
{
	std::string Type[3] = { "Health","Education","Science" }, sTemp;
	std::ifstream In; int NUM, nTemp, loc = 0; std::stringstream TURN;
	for (int i = 0; i < 3; i++) {
		sTemp = "./Data\\" + Type[i] + ".txt";
		In.open(sTemp.c_str(), std::ios::in);
		for (int j = 0; j < 10; j++) {
			In >> m_LookUp[loc].Name;
			In >> NUM;
			m_LookUp[loc].Type = Type[i];
			for (int p = 0; p < NUM; p++) {
				In >> sTemp;
				In >> nTemp;
				if (HasIt(sTemp))
					m_LookUp[loc].Num += nTemp;
				sTemp.clear();
			}
			loc++;
		}
		In.close();
		In.clear();
	}
	std::sort(m_LookUp, m_LookUp + 30, this->Cmp);
}

void RECOUT::CreatText()
{
	std::ifstream In; std::stringstream Turn; std::string sTemp;
	for (int i = 0; i < 5; i++) {
		sTemp = "./Data\\" + m_LookUp[i].Type + '\\' + m_LookUp[i].Name + ".txt";
		In.open(sTemp.c_str(), std::ios::in);
		if (!In.is_open())
			MessageBox(TEXT("未成功打开"));
		sTemp.clear();
		m_Text[i].Name = m_LookUp[i].Name;
		Turn << m_LookUp[i].Num;
		Turn >> m_Text[i].Num;
		Turn.clear();
		m_Text[i].Type = m_LookUp[i].Type;
		while (In.peek() != EOF) {
			std::getline(In, sTemp, '\n');
			m_Text[i].Text += "  " + sTemp + "\r\n\r\n";
			sTemp.clear();
		}
		In.close();
	}
}

bool RECOUT::HasIt(std::string& str)
{
	int end = m_Choice.size();
	for (int i = 0; i < end; i++) {
		if (str == m_Choice[i])
			return true;
	}
	return false;
}

bool RECOUT::Cmp(const UN& x, const UN& y)
{
	if (x.Num == y.Num) {
		return x.Name < y.Name;
	}
	else return x.Num > y.Num;
}

void RECOUT::OnTcnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult)
{
	// TODO: 在此添加控件通知处理程序代码
	//把当前的页面隐藏起来
	m_Dlg[m_TabType]->ShowWindow(SW_HIDE);
	//得到新的页面索引
	m_TabType = m_Tab.GetCurSel();
	//把新的页面显示出来
	m_Dlg[m_TabType]->ShowWindow(SW_SHOW);
	*pResult = 0;
}


void RECOUT::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	for (int i = 0; i < 5; i++)
		delete(m_Dlg[i]);
	CDialogEx::OnCancel();
}

bool RECOUT::GetChoice(const CString& A, const CString& B, const CString& C)
{
	if (!A.IsEmpty())
		m_Choice.push_back((std::string)CT2A(A.GetString()));
	if (!B.IsEmpty())
		m_Choice.push_back((std::string)CT2A(B.GetString()));
	if (!C.IsEmpty())
		m_Choice.push_back((std::string)CT2A(C.GetString()));
	if (A.IsEmpty() && B.IsEmpty() && C.IsEmpty()) {
		MessageBox(TEXT("未选择任何关键词"));
		return false;
	}
	return true;
}
