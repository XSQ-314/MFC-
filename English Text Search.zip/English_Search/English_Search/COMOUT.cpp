﻿// COMOUT.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "COMOUT.h"
#include "afxdialogex.h"
#define EX 0

// COMOUT 对话框

IMPLEMENT_DYNAMIC(COMOUT, CDialogEx)

COMOUT::COMOUT(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_COMPAREOUT, pParent)
{

}

COMOUT::~COMOUT()
{
}

void COMOUT::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_OUT, m_Out);

	m_Out.SetWindowTextW(Compare());

}

CString COMOUT::Compare()
{
	ToWord((std::string)CT2A(m_TextA.GetString()), (std::string)CT2A(m_TextB.GetString()));
	int End = m_WordA.size(), Same = 0;
	for (int i = 0; i < End; i++) {
		int Top = m_WordB.size();
		for (int j = 0; j < Top; j++) {

			if (!i)
				nWordB += m_WordB[j].num;//统计B中关键词相同个数

			if (m_WordA[i].word == m_WordB[j].word) {
				Same += (m_WordA[i].num < m_WordB[j].num ? m_WordA[i].num : m_WordB[j].num);
				break;
			}
			else
				continue;
		}
		nWordA += m_WordA[i].num;//统计A中关键词相同个数
	}
	std::stringstream TURN; std::string sTemp;
	TURN << ((((double)(Same)-(EX)) / ((double)(nWordA > nWordB ? nWordA : nWordB)-(EX))) * 100);
	TURN >> sTemp;
	sTemp = ("相似度为：" + sTemp + "%");

	return CA2T(sTemp.c_str());
}

bool COMOUT::Cmp(const DATA& x, const DATA& y)
{
	if (x.num == y.num) {
		return x.word < y.word;
	}
	else return x.num > y.num;
}

void COMOUT::ToWord(std::string TextA, std::string TextB)
{
	int top = TextA.size(), NUM; DATA temp; bool flag = false;
	std::vector<std::string> keyword; std::ifstream In;
	std::string sTemp;
	In.open(".\\Data\\keyword.txt", std::ios::in);
	while (In.peek() != EOF) {
		In >> sTemp;
		In >> NUM;
		sTemp.clear();
		for (int i = 0; i < NUM; i++) {
			In >> sTemp;
			keyword.push_back(sTemp);
			sTemp.clear();
		}
	}
	In.close();
	for (int i = 0; i < top; i++) {
		if (TextA[i] != ' ' && TextA[i] != ',' && TextA[i] != '.' && TextA[i] != '\"' && TextA[i] != '(' && TextA[i] != ')') {
			temp.word.push_back(TextA[i]);
			flag = true;
		}
		else if (flag) {
			if (temp.word != "COVID-19" && temp.word != "NASA")
				transform(temp.word.begin(), temp.word.end(), temp.word.begin(), tolower);
			if (temp.word == "schools")temp.word = "school";
			else if (temp.word == "students")temp.word = "student";
			else if (temp.word == "colleges")temp.word = "college";
			else if (temp.word == "universities")temp.word = "university";
			if (!HasIt(m_WordA, temp.word) && HasIt(keyword, temp.word))
				m_WordA.push_back(temp);
			temp.word.clear();
			flag = false;
		}
	}
	top = TextB.size();
	for (int i = 0; i < top; i++) {
		if (TextB[i] != ' ' && TextB[i] != ',' && TextB[i] != '.' && TextB[i] != '\"' && TextB[i] != '(' && TextB[i] != ')') {
			temp.word.push_back(TextB[i]);
			flag = true;
		}
		else if (flag) {
			if (temp.word != "COVID-19" && temp.word != "NASA")
				transform(temp.word.begin(), temp.word.end(), temp.word.begin(), tolower);
			if (temp.word == "schools")temp.word = "school";
			else if (temp.word == "students")temp.word = "student";
			else if (temp.word == "colleges")temp.word = "college";
			else if (temp.word == "universities")temp.word = "university";
			if (!HasIt(m_WordB, temp.word) && HasIt(keyword, temp.word))
				m_WordB.push_back(temp);
			temp.word.clear();
			flag = false;
		}
	}
	std::sort(m_WordA.begin(), m_WordA.end(), Cmp);
	std::sort(m_WordB.begin(), m_WordB.end(), Cmp);
}

bool COMOUT::HasIt(std::vector<DATA>& word, const std::string& Word)
{
	int end = word.size();
	for (int i = 0; i < end; i++) {
		if (Word == word[i].word) {
			word[i].num++;
			return true;
		}
		else continue;
	}
	return false;
}

bool COMOUT::HasIt(const std::vector<std::string>& keyword, const std::string& Word)
{
	int end = keyword.size();
	for (int i = 0; i < end; i++) {
		if (Word == keyword[i]) {
			return true;
		}
		else continue;
	}
	return false;
}

void COMOUT::GetData(const CString& TextA, const CString& TextB)
{
	m_TextA = TextA; m_TextB = TextB;
}


BEGIN_MESSAGE_MAP(COMOUT, CDialogEx)
	ON_BN_CLICKED(IDOK, &COMOUT::OnBnClickedOk)
END_MESSAGE_MAP()


// COMOUT 消息处理程序


void COMOUT::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	m_Out.SetWindowTextW(TEXT(""));
	CDialogEx::OnOK();
}
