﻿// OUTTEXT.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "OUTTEXT.h"
#include "afxdialogex.h"


// OUTTEXT 对话框

IMPLEMENT_DYNAMIC(OUTTEXT, CDialogEx)

OUTTEXT::OUTTEXT(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_OUT, pParent)
{

}

OUTTEXT::~OUTTEXT()
{
}

void OUTTEXT::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Text);
	m_Font.CreatePointFont(100, _T("幼圆"));
	m_Text.SetFont(&m_Font);
	DDX_Control(pDX, IDC_EDIT2, m_Name);
	DDX_Control(pDX, IDC_EDIT4, m_Type);
	DDX_Control(pDX, IDC_NUM, m_Num);
}

void OUTTEXT::ShowText(const Text& Data)
{
	m_Text.SetWindowTextW((CString)CA2T(Data.Text.c_str()));
	m_Name.SetWindowTextW((CString)CA2T(Data.Name.c_str()));
	m_Type.SetWindowTextW((CString)CA2T(Data.Type.c_str()));
	m_Num.SetWindowTextW((CString)CA2T(Data.Num.c_str()));
}


BEGIN_MESSAGE_MAP(OUTTEXT, CDialogEx)
END_MESSAGE_MAP()


// OUTTEXT 消息处理程序


BOOL OUTTEXT::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class
	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_RETURN)
			return TRUE;//截获消息 
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}
