﻿// GETKEY_KEY.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "GETKEY_KEY.h"
#include "afxdialogex.h"


// GETKEY_KEY 对话框

IMPLEMENT_DYNAMIC(GETKEY_KEY, CDialogEx)

GETKEY_KEY::GETKEY_KEY(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_KEY, pParent)
{

}

GETKEY_KEY::~GETKEY_KEY()
{
}

void GETKEY_KEY::GetText(const CString& Text)
{
	m_Text = Text;
}

void GETKEY_KEY::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Key);
	m_Font.CreatePointFont(100, _T("楷体"));
	m_Key.SetFont(&m_Font);
	std::string Temp = CT2A(m_Text.GetString());
	ToWord(Temp);
	Statistics();
	m_Key.SetWindowTextW(m_Text);
}

bool GETKEY_KEY::Cmp(const DATA& x, const DATA& y)
{
	if (x.num == y.num) {
		return x.word < y.word;
	}
	else return x.num > y.num;
}

int GETKEY_KEY::Find(const std::string& Word)
{
	if (m_Data.empty()) {//为空则创建一个目标
		DATA Temp;
		Temp.word = Word;//临时目标赋值为该地址
		m_Data.push_back(Temp);//存入
		return 0;//返回该目标位置
	}
	int i = 0, end = m_Data.size();//获取容器尾部
	while (m_Data[i++].word != Word) {//当不等于时继续
		if (i == end) {//遍历完也没有找到则创建一个
			DATA Temp;
			Temp.word = Word;//临时目标赋值为该地址
			m_Data.push_back(Temp);//存入
			return end;//返回该目标位置
		}
	}
	return --i;//返回位置	因为上面已经执行++所以进行--
}

bool GETKEY_KEY::HasIt(const std::vector<std::string>& keyword, const std::string& Word)
{
	int end = keyword.size();
	for (int i = 0; i < end; i++) {
		if (Word == keyword[i])
			return true;
		else continue;
	}
	return false;
}

void GETKEY_KEY::Statistics()
{
	int top = m_Word.size(), NUM, loc; std::ifstream In; std::stringstream ToStr;
	std::vector<std::string> keyword; std::string line, temp, Temp, Num;
	In.open(".\\Data\\keyword.txt", std::ios::in);
	while (In.peek() != EOF) {
		In >> temp;
		In >> NUM;
		temp.clear();
		for (int i = 0; i < NUM; i++) {
			In >> temp;
			keyword.push_back(temp);
			temp.clear();
		}
	}
	In.close();
	for (int i = 0; i < top; i++) {
		if (!HasIt(keyword, m_Word[i])) {
			continue;
		}
		else {
			loc = Find(m_Word[i]);
			m_Data[loc].loc.push_back(i + 1);
			m_Data[loc].num++;
		}
	}
	sort(m_Data.begin(), m_Data.end(), this->Cmp);
	top = m_Data.size();
	for (int i = 0; i < top; i++) {
		if (m_Data[i].num >= 2) {
			int end = m_Data[i].loc.size();
			for (int j = 0; j < end; j++) {
				ToStr << m_Data[i].loc[j];
				ToStr >> temp;
				Temp += (temp + '\t');
				ToStr.clear(); temp.clear();
			}
			ToStr << m_Data[i].num; ToStr >> Num;
			line += ("单词:" + m_Data[i].word + "\r\n出现次数：" + Num + "\r\n出现位置：\t" + Temp + "\r\n\r\n");
			Temp.clear(); Num.clear(); ToStr.clear();
		}
	}
	m_Text = CA2T(line.c_str());
}

void GETKEY_KEY::ToWord(std::string& Text)
{
	int top = Text.size(); std::string temp; bool flag = false;
	for (int i = 0; i < top; i++) {
		if (Text[i] != ' ' && Text[i] != ',' && Text[i] != '.' && Text[i] != '\"' && Text[i] != '(' && Text[i] != ')') {
			temp.push_back(Text[i]);
			flag = true;
		}
		else if (flag) {
			if (temp != "COVID-19" && temp != "NASA")
				transform(temp.begin(), temp.end(), temp.begin(), tolower);
			if (temp == "schools")temp = "school";
			else if (temp == "students")temp = "student";
			else if (temp == "colleges")temp = "college";
			else if (temp == "universities")temp = "university";
			m_Word.push_back(temp);
			temp.clear();
			flag = false;
		}
	}
}


BEGIN_MESSAGE_MAP(GETKEY_KEY, CDialogEx)
	ON_BN_CLICKED(IDOK, &GETKEY_KEY::OnBnClickedOk)
END_MESSAGE_MAP()


// GETKEY_KEY 消息处理程序


void GETKEY_KEY::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	CDialogEx::OnCancel();
}
