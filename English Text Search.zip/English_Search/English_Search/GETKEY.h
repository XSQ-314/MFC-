﻿#pragma once
#include"GETKEY_KEY.h"

// GETKEY 对话框

class GETKEY : public CDialogEx
{
	DECLARE_DYNAMIC(GETKEY)

public:
	GETKEY(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~GETKEY();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_GETKEY };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
private:
	CEdit m_Gettext;
	
public:
	afx_msg void OnBnClickedButton1();
};
