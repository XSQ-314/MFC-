﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 EnglishSearch.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ENGLISH_SEARCH_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_GETKEY                      131
#define IDD_COMPARE                     132
#define IDD_RECOMMEND                   133
#define IDD_KEY                         137
#define IDD_COMPAREOUT                  139
#define IDD_RECOUT                      141
#define IDD_OUT                         143
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_EDIT1                       1004
#define IDC_BUTTON4                     1005
#define IDC_EDIT3                       1005
#define IDC_EDIT2                       1006
#define IDC_EDIT4                       1007
#define IDC_OUT                         1008
#define IDC_TAB1                        1009
#define IDC_COMBO2                      1012
#define IDC_COMBO3                      1013
#define IDC_NUM                         1013
#define IDC_COMBO4                      1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
