﻿#pragma once
#include<string>
#include<vector>
#include<algorithm>
#include<sstream>
#include<fstream>
// GETKEY_KEY 对话框

class GETKEY_KEY : public CDialogEx
{
	DECLARE_DYNAMIC(GETKEY_KEY)

public:
	GETKEY_KEY(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~GETKEY_KEY();
	void GetText(const CString& Text);

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_KEY };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
private:
	struct DATA {
		std::string word;
		int num = 0;
		std::vector<int> loc;
	};
	static bool Cmp(const DATA& x, const DATA& y);
	int Find(const std::string& Word);
	bool HasIt(const std::vector<std::string>& emptyword, const std::string& Word);
	void Statistics();
	void ToWord(std::string& Text);
	CFont m_Font;
	CString m_Text;
	std::vector<std::string> m_Word;
	std::vector<DATA> m_Data;
	CEdit m_Key;
public:
	afx_msg void OnBnClickedOk();
};
