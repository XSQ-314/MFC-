﻿#pragma once
#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<sstream>
#include<algorithm>

// COMOUT 对话框

class COMOUT : public CDialogEx
{
	DECLARE_DYNAMIC(COMOUT)

public:
	COMOUT(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~COMOUT();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_COMPAREOUT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
private:
	struct DATA {
		std::string word;
		int num = 1;
	};
	CString m_TextA, m_TextB;
	std::vector<DATA> m_WordA, m_WordB;
	CStatic m_Out;
	int nWordA = 0, nWordB = 0;
	CString Compare();
	static bool Cmp(const DATA& x, const DATA& y);
	void ToWord(std::string TextA, std::string TextB);
	bool HasIt(std::vector<DATA>& word, const std::string& Word);
	bool HasIt(const std::vector<std::string>& keyword, const std::string& Word);
public:
	void GetData(const CString& TextA, const CString& TextB);
	afx_msg void OnBnClickedOk();
};
