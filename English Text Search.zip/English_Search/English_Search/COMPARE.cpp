﻿// COMPARE.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "COMPARE.h"
#include "afxdialogex.h"


// COMPARE 对话框

IMPLEMENT_DYNAMIC(COMPARE, CDialogEx)

COMPARE::COMPARE(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_COMPARE, pParent)
{

}

COMPARE::~COMPARE()
{
}

void COMPARE::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_TextA);
	DDX_Control(pDX, IDC_EDIT2, m_TextB);
}


BEGIN_MESSAGE_MAP(COMPARE, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &COMPARE::OnBnClickedButton1)
END_MESSAGE_MAP()


// COMPARE 消息处理程序


void COMPARE::OnBnClickedButton1()//生成对比结果
{
	COMOUT *m_Out=new COMOUT;
	// TODO: 在此添加控件通知处理程序代码
	CString TextA, TextB;
	m_TextA.GetWindowTextW(TextA);
	m_TextB.GetWindowTextW(TextB);
	m_Out->GetData(TextA, TextB);//传入参数
	m_Out->DoModal();
	delete(m_Out);
}
