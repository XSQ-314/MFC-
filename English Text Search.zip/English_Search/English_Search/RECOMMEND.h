﻿#pragma once
#include"RECOUT.h"

// RECOMMEND 对话框

class RECOMMEND : public CDialogEx
{
	DECLARE_DYNAMIC(RECOMMEND)

public:
	RECOMMEND(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~RECOMMEND();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_RECOMMEND };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButton1();
private:
	CComboBox m_Choice1;
	CComboBox m_Choice2;
	CComboBox m_Choice3;
	CFont m_Font;
	bool HasIt(const std::vector<std::string>& emptyword, const std::string& Word);
	std::vector<std::string> keyword;
public:
	afx_msg void OnBnClickedOk();
};
