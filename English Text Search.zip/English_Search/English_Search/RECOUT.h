﻿#pragma once
#include"OUTTEXT.h"

// RECOUT 对话框

class RECOUT : public CDialogEx
{
	DECLARE_DYNAMIC(RECOUT)

public:
	RECOUT(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~RECOUT();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_RECOUT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
private:
	struct UN{
		int Num=0;
		std::string Type, Name;
	};
	UN m_LookUp[30];
	std::vector<std::string> m_Choice;
	int m_TabType = 0;
	CTabCtrl m_Tab;
	OUTTEXT* m_Dlg[5];
	Text m_Text[5];
	void Initialize();
	void Search();
	void CreatText();
	bool HasIt(std::string &str);
	static bool Cmp(const UN& x, const UN& y);
public:
	afx_msg void OnTcnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBnClickedOk();
	bool GetChoice(const CString& A, const CString& B, const CString& C);
};
