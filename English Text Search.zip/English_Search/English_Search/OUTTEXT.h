﻿#pragma once
#include<iostream>
#include<fstream>
#include<sstream>
#include<vector>
#include<string>
#include<algorithm>

// OUTTEXT 对话框

struct Text {
	std::string Name, Type, Text, Num;
};

class OUTTEXT : public CDialogEx
{
	DECLARE_DYNAMIC(OUTTEXT)

public:
	OUTTEXT(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~OUTTEXT();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_OUT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
private:
	CEdit m_Text;
	CFont m_Font;
public:
	void ShowText(const Text& Data);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
private:
	CEdit m_Name;
	CEdit m_Type;
	CStatic m_Num;
};
