﻿// GETKEY.cpp: 实现文件
//

#include "pch.h"
#include "English_Search.h"
#include "GETKEY.h"
#include "afxdialogex.h"


// GETKEY 对话框

IMPLEMENT_DYNAMIC(GETKEY, CDialogEx)

GETKEY::GETKEY(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_GETKEY, pParent)
{

}

GETKEY::~GETKEY()
{
}

void GETKEY::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Gettext);
}


BEGIN_MESSAGE_MAP(GETKEY, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &GETKEY::OnBnClickedButton1)
END_MESSAGE_MAP()


// GETKEY 消息处理程序


void GETKEY::OnBnClickedButton1()
{
	GETKEY_KEY *m_Key=new GETKEY_KEY;
	// TODO: 在此添加控件通知处理程序代码
	CString Text;
	m_Gettext.GetWindowTextW(Text);
	m_Key->GetText(Text);
	m_Key->DoModal();
	delete(m_Key);
}
