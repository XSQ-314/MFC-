﻿#pragma once
#include"COMOUT.h"


// COMPARE 对话框

class COMPARE : public CDialogEx
{
	DECLARE_DYNAMIC(COMPARE)

public:
	COMPARE(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~COMPARE();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_COMPARE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
private:
	
	CEdit m_TextA;
	CEdit m_TextB;
};
